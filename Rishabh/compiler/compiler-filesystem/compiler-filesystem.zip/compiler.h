#ifndef _COMPILER_H
#define _COMPILER_H

void *compile(char *sourceData, unsigned int *destFileLength);

#endif