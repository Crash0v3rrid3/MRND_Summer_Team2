#ifndef _util_h
#define _util_h

char *getFileData(char *filename);
char *cloneStr(char *str);

#endif